// =====================================================
//  Sistema VetCat
// =====================================================

// ---------- STORAGE CENTRAL ----------
const DB = {
  pets: JSON.parse(localStorage.getItem('pets')) || [],
  owners: JSON.parse(localStorage.getItem('owners')) || [],
  vets: JSON.parse(localStorage.getItem('vets')) || []
};

const saveDB = () => {
  Object.keys(DB).forEach(key => {
    localStorage.setItem(key, JSON.stringify(DB[key]));
  });
};

// ---------- UTILIDADES ----------
const $ = (id) => document.getElementById(id);

const limpiarInputs = (ids) => {
  ids.forEach(id => $(id).value = '');
};

const generarID = () => Date.now();

// ---------- NAVEGACIÓN ----------
const router = (view, btn) => {
  document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
  btn?.classList.add('active');

  const cont = $('contenido-dinamico');
  cont.innerHTML = '';

  const vistas = {
    mascotas: viewMascotas,
    propietarios: viewOwners,
    veterinarios: viewVets
  };

  vistas[view]?.();
};

// =====================================================
//  MASCOTAS
// =====================================================
const viewMascotas = () => {
  $('contenido-dinamico').innerHTML = `
    <h2>🐾 Mascotas</h2>
    <div class="card-form">
      <input id="petName" placeholder="Nombre">
      <input id="petAge" type="number" placeholder="Edad">
      <input id="petType" placeholder="Tipo">
      <input id="petOwner" placeholder="Propietario">
      <button onclick="addPet()">Agregar</button>
    </div>
    <div id="listPets"></div>
  `;
  renderPets();
};

const addPet = () => {
  const data = {
    id: generarID(),
    nombre: $('petName').value,
    edad: $('petAge').value,
    tipo: $('petType').value,
    propietario: $('petOwner').value
  };

  if (Object.values(data).some(v => !v)) {
    return alert('Campos incompletos');
  }

  DB.pets.push(data);
  saveDB();
  renderPets();
  limpiarInputs(['petName','petAge','petType','petOwner']);
};

const renderPets = () => {
  const cont = $('listPets');
  cont.innerHTML = DB.pets.length
    ? DB.pets.map((p,i) => `
      <div class="item">
        ${p.nombre} (${p.tipo})
        <button onclick="editPet(${i})">✏️</button>
        <button onclick="deletePet(${i})">🗑️</button>
      </div>
    `).join('')
    : '<p>No hay mascotas</p>';
};

const editPet = (i) => {
  let p = DB.pets[i];
  let nuevo = prompt('Nuevo nombre:', p.nombre);
  if (!nuevo) return;

  DB.pets[i].nombre = nuevo;
  saveDB();
  renderPets();
};

const deletePet = (i) => {
  if (!confirm('Eliminar mascota?')) return;
  DB.pets.splice(i,1);
  saveDB();
  renderPets();
};

// =====================================================
//  PROPIETARIOS
// =====================================================
const viewOwners = () => {
  $('contenido-dinamico').innerHTML = `
    <h2>👤 Propietarios</h2>
    <input id="ownerName" placeholder="Nombre">
    <input id="ownerPhone" placeholder="Teléfono">
    <button onclick="addOwner()">Agregar</button>
    <div id="listOwners"></div>
  `;
  renderOwners();
};

const addOwner = () => {
  DB.owners.push({
    id: generarID(),
    nombre: $('ownerName').value,
    telefono: $('ownerPhone').value
  });

  saveDB();
  renderOwners();
  limpiarInputs(['ownerName','ownerPhone']);
};

const renderOwners = () => {
  $('listOwners').innerHTML = DB.owners.map((o,i) => `
    <div>${o.nombre} - ${o.telefono}
      <button onclick="deleteOwner(${i})">❌</button>
    </div>
  `).join('');
};

const deleteOwner = (i) => {
  DB.owners.splice(i,1);
  saveDB();
  renderOwners();
};

// =====================================================
//  VETERINARIOS
// =====================================================
const viewVets = () => {
  $('contenido-dinamico').innerHTML = `
    <h2>🩺 Veterinarios</h2>
    <input id="vetName" placeholder="Nombre">
    <input id="vetSpec" placeholder="Especialidad">
    <button onclick="addVet()">Agregar</button>
    <div id="listVets"></div>
  `;
  renderVets();
};

const addVet = () => {
  DB.vets.push({
    id: generarID(),
    nombre: $('vetName').value,
    especialidad: $('vetSpec').value
  });

  saveDB();
  renderVets();
  limpiarInputs(['vetName','vetSpec']);
};

const renderVets = () => {
  $('listVets').innerHTML = DB.vets.map((v,i) => `
    <div>${v.nombre} - ${v.especialidad}
      <button onclick="deleteVet(${i})">❌</button>
    </div>
  `).join('');
};

const deleteVet = (i) => {
  DB.vets.splice(i,1);
  saveDB();
  renderVets();
};

// ---------- LOGOUT ----------
const logout = () => {
  localStorage.clear();
  location.href = "index.html";
};

