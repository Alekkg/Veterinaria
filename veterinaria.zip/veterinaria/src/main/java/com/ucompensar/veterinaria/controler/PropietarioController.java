package com.ucompensar.veterinaria.controler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ucompensar.veterinaria.model.entity.Propietario;
import com.ucompensar.veterinaria.service.PropietarioService;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/api/propietario")
public class PropietarioController extends HttpServlet {

    private final PropietarioService service = new PropietarioService();
    private final ObjectMapper mapper = new ObjectMapper();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        resp.setContentType("application/json");

        String id = req.getParameter("id");
        if (id != null) {
            Propietario propietario = service.buscarPorId(Long.parseLong(id));
            mapper.writeValue(resp.getWriter(), propietario);
        } else {
            List<Propietario> propietario = service.listarTodos();
            mapper.writeValue(resp.getWriter(), propietario);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Propietario propietario = mapper.readValue(req.getInputStream(), Propietario.class);
        service.crear(propietario);
        resp.setStatus(HttpServletResponse.SC_CREATED);
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Propietario propietario = mapper.readValue(req.getInputStream(), Propietario.class);
        service.actualizar(propietario);
        resp.setStatus(HttpServletResponse.SC_OK);
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String id = req.getParameter("id");
        service.eliminar(Long.parseLong(id));
        resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
    }

}
