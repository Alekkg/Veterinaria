package com.ucompensar.veterinaria.dao;

import com.ucompensar.veterinaria.model.entity.Propietario;
import jakarta.persistence.EntityManager;

public class PropietarioDAO extends GenericDAO<Propietario, Long>{
    
    public PropietarioDAO(EntityManager em){
        super (em, Propietario.class);
    }
}
