package com.ucompensar.veterinaria.controler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ucompensar.veterinaria.model.entity.HistorialClinico;
import com.ucompensar.veterinaria.service.HistorialClinicoService;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/api/historial")

public class HistorialClinicoController extends HttpServlet{
    
    private final HistorialClinicoService service = new HistorialClinicoService();
    private final ObjectMapper mapper = new ObjectMapper();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        resp.setContentType("application/json");

        String id = req.getParameter("id");
        if (id != null) {
            HistorialClinico historialClinico = service.buscarPorId(Long.parseLong(id));
            mapper.writeValue(resp.getWriter(), historialClinico);
        } else {
            List<HistorialClinico> historialClinico = service.listarTodos();
            mapper.writeValue(resp.getWriter(), historialClinico);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HistorialClinico historialClinico = mapper.readValue(req.getInputStream(), HistorialClinico.class);
        service.crear(historialClinico);
        resp.setStatus(HttpServletResponse.SC_CREATED);
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HistorialClinico historialClinico = mapper.readValue(req.getInputStream(), HistorialClinico.class);
        service.actualizar(historialClinico);
        resp.setStatus(HttpServletResponse.SC_OK);
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String id = req.getParameter("id");
        service.eliminar(Long.parseLong(id));
        resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
    }
}
