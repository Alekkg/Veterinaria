package com.ucompensar.veterinaria.dao;

import com.ucompensar.veterinaria.model.entity.HistorialClinico;
import jakarta.persistence.EntityManager;

public class HistorialClinicoDAO extends GenericDAO<HistorialClinico, Long>{
    public HistorialClinicoDAO(EntityManager em){
        super (em, HistorialClinico.class);
    }
}
