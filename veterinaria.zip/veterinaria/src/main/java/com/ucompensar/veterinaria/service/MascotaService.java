package com.ucompensar.veterinaria.service;

import com.ucompensar.veterinaria.dao.MascotaDAO;
import com.ucompensar.veterinaria.model.entity.Mascota;
import com.ucompensar.veterinaria.util.JPAUtil;
import jakarta.persistence.EntityManager;
import java.util.List;


public class MascotaService {
    
    public void crear (Mascota mascota){
        EntityManager em = JPAUtil.getEntityManager();
        try {
            new MascotaDAO(em).crear(mascota);
        } finally {
            em.close();
        }
    }
    
    public Mascota buscarPorId(Long id){
        EntityManager em = JPAUtil.getEntityManager();
        try {
            return new MascotaDAO(em).buscarPorId(id);
        } finally {
            em.close();
        }
    }
    
    public List<Mascota> listarTodos(){
        EntityManager em = JPAUtil.getEntityManager();
        try {
            return new MascotaDAO(em).listarTodos();
        } finally {
            em.close();
        }
    }
    
    public List<Mascota> listarPropietario(Long idPropietario){
        EntityManager em = JPAUtil.getEntityManager();
        try{
            return new MascotaDAO(em).buscarPorPropietario(idPropietario);
        }
        finally {
            em.close();
        }
    }
    
    public void actualizar (Mascota mascota){
        EntityManager em = JPAUtil.getEntityManager();
        try {
                new MascotaDAO(em).actualizar(mascota);
        } finally {
            em.close();
        }
    }
    
    public void eliminar (Long id){
        EntityManager em = JPAUtil.getEntityManager();
        try {
            new MascotaDAO(em).eliminar(id);
        } finally {
            em.close();
        }
    }
}
