package com.ucompensar.veterinaria.dao;

import com.ucompensar.veterinaria.model.entity.Tratamiento;
import jakarta.persistence.EntityManager;
import java.util.List;


public class TratamientoDAO extends GenericDAO<Tratamiento, Long> {
    
    public TratamientoDAO(EntityManager em){
        super (em, Tratamiento.class);
    }
    
    public List<Tratamiento> buscarPorPropietario(Long idHistorial){
        return em.createQuery(
                "SELECT t FROM Tratamiento t WHERE t.historial.idHistorialClinico = :id ",
                Tratamiento.class
        ).setParameter("id", idHistorial)
         .getResultList();
        
    }
}
