
package com.ucompensar.veterinaria.dao;

import com.ucompensar.veterinaria.model.entity.Vacunacion;
import jakarta.persistence.EntityManager;

public class VacunacionDAO extends GenericDAO<Vacunacion, Long>{
    
    public VacunacionDAO(EntityManager em){
        super (em, Vacunacion.class);
    }
}
