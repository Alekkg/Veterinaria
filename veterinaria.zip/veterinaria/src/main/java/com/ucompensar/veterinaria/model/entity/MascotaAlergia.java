
package com.ucompensar.veterinaria.model.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;



@Entity
@Table(name = "mascotaalergia")
public class MascotaAlergia{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne
    @JoinColumn(name = "idMascota", nullable = false)
    private Mascota  mascotaAlergia;
    
    @ManyToOne
    @JoinColumn(name = "idAlergia", nullable = false)
    private Alergia alergia;
    
    private String observaciones;
    
    
//Getters - Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Mascota getMascotaAlergia() {
        return mascotaAlergia;
    }

    public void setMascotaAlergia(Mascota mascotaAlergia) {
        this.mascotaAlergia = mascotaAlergia;
    }

    public Alergia getAlergia() {
        return alergia;
    }

    public void setAlergia(Alergia alergia) {
        this.alergia = alergia;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

   
   
    
}
