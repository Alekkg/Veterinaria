package com.ucompensar.veterinaria.controler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ucompensar.veterinaria.model.entity.Veterinario;
import com.ucompensar.veterinaria.service.VeterinarioService;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;  
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet ("/api/veterinario")
public class VeterinarioController extends HttpServlet {
    
    private final VeterinarioService service = new VeterinarioService();
    private final ObjectMapper mapper = new ObjectMapper();
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        resp.setContentType("application/json");

        String id = req.getParameter("id");
        if (id != null) {
            Veterinario veterinario = service.buscarPorId(Long.parseLong(id));
            mapper.writeValue(resp.getWriter(), veterinario);
        } else {
            List<Veterinario> veterinario = service.listarTodos();
            mapper.writeValue(resp.getWriter(), veterinario);
        }
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Veterinario veterinario = mapper.readValue(req.getInputStream(), Veterinario.class);
        service.crear(veterinario);
        resp.setStatus(HttpServletResponse.SC_CREATED);
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Veterinario veterinario = mapper.readValue(req.getInputStream(), Veterinario.class);
        service.actualizar(veterinario);
        resp.setStatus(HttpServletResponse.SC_OK);
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String id = req.getParameter("id");
        service.eliminar(Long.parseLong(id));
        resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
    }
}
