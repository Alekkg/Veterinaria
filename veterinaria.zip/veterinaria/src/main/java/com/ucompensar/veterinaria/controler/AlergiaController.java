package com.ucompensar.veterinaria.controler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ucompensar.veterinaria.model.entity.Alergia;
import com.ucompensar.veterinaria.service.AlergiaService;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/api/alergias")
public class AlergiaController extends HttpServlet {

    private final AlergiaService service = new AlergiaService();
    private final ObjectMapper mapper = new ObjectMapper();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        resp.setContentType("application/json");

        String id = req.getParameter("id");
        if (id != null) {
            Alergia alergia = service.buscarPorId(Long.parseLong(id));
            mapper.writeValue(resp.getWriter(), alergia);
        } else {
            List<Alergia> alergia = service.listarTodos();
            mapper.writeValue(resp.getWriter(), alergia);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Alergia alergia = mapper.readValue(req.getInputStream(), Alergia.class);
        service.crear(alergia);
        resp.setStatus(HttpServletResponse.SC_CREATED);
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Alergia alergia = mapper.readValue(req.getInputStream(), Alergia.class);
        service.actualizar(alergia);
        resp.setStatus(HttpServletResponse.SC_OK);
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String id = req.getParameter("id");
        service.eliminar(Long.parseLong(id));
        resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
    }

}
