
package com.ucompensar.veterinaria.service;

import com.ucompensar.veterinaria.dao.PropietarioDAO;
import com.ucompensar.veterinaria.model.entity.Propietario;
import com.ucompensar.veterinaria.util.JPAUtil;

import jakarta.persistence.EntityManager;
import java.util.List;

public class PropietarioService {
 
    public void crear (Propietario propietario){
        EntityManager em = JPAUtil.getEntityManager();
        try {
            new PropietarioDAO(em).crear(propietario);
        } finally{
            em.close();
        }
    }
    
    public Propietario buscarPorId(Long id){
        EntityManager em = JPAUtil.getEntityManager();
        try{
            return new PropietarioDAO(em).buscarPorId(id);
        }finally{
            em.close();
        }
    }
    
    public List<Propietario> listarTodos(){
       EntityManager em = JPAUtil.getEntityManager();
       try{
           return new PropietarioDAO(em).listarTodos();
       }finally{
           em.close();
       }
    }
    
    public void actualizar(Propietario propietario){
        EntityManager em = JPAUtil.getEntityManager();
        try{
            new PropietarioDAO(em).actualizar(propietario);
        }finally{
            em.close();
        }
    }
    
    public void eliminar(Long id){
        EntityManager em = JPAUtil.getEntityManager();
        try{
            new PropietarioDAO(em).eliminar(id);
        }finally{
            em.close();
        }
    }
}
