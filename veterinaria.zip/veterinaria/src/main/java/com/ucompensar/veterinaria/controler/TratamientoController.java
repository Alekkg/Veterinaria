package com.ucompensar.veterinaria.controler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ucompensar.veterinaria.model.entity.Tratamiento;
import com.ucompensar.veterinaria.service.TratamientoService;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/api/propietario")
public class TratamientoController extends HttpServlet {

    private final TratamientoService service = new TratamientoService();
    private final ObjectMapper mapper = new ObjectMapper();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        resp.setContentType("application/json");

        String id = req.getParameter("id");
        if (id != null) {
            Tratamiento tratamiento = service.buscarPorId(Long.parseLong(id));
            mapper.writeValue(resp.getWriter(), tratamiento);
        } else {
            List<Tratamiento> tratamiento = service.listarTodos();
            mapper.writeValue(resp.getWriter(), tratamiento);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Tratamiento tratamiento = mapper.readValue(req.getInputStream(), Tratamiento.class);
        service.crear(tratamiento);
        resp.setStatus(HttpServletResponse.SC_CREATED);
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Tratamiento tratamiento = mapper.readValue(req.getInputStream(), Tratamiento.class);
        service.actualizar(tratamiento);
        resp.setStatus(HttpServletResponse.SC_OK);
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String id = req.getParameter("id");
        service.eliminar(Long.parseLong(id));
        resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
    }
}
