package com.ucompensar.veterinaria.controler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ucompensar.veterinaria.model.entity.Medicamento;
import com.ucompensar.veterinaria.service.MedicamentoService;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/api/medicamentos")
public class MedicamentoController extends HttpServlet {
 
    private final MedicamentoService service = new MedicamentoService();
    private final ObjectMapper mapper = new ObjectMapper();
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        resp.setContentType("application/json");

        String id = req.getParameter("id");
        if (id != null) {
            Medicamento medicamento = service.buscarPorId(Long.parseLong(id));
            mapper.writeValue(resp.getWriter(), medicamento);
        } else {
            List<Medicamento> medicamento = service.listarTodos();
            mapper.writeValue(resp.getWriter(), medicamento);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Medicamento medicamento = mapper.readValue(req.getInputStream(), Medicamento.class);
        service.crear(medicamento);
        resp.setStatus(HttpServletResponse.SC_CREATED);
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Medicamento medicamento = mapper.readValue(req.getInputStream(), Medicamento.class);
        service.actualizar(medicamento);
        resp.setStatus(HttpServletResponse.SC_OK);
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String id = req.getParameter("id");
        service.eliminar(Long.parseLong(id));
        resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
    }
}
