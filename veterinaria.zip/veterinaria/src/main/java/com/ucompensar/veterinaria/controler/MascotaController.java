package com.ucompensar.veterinaria.controler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ucompensar.veterinaria.model.entity.Mascota;
import com.ucompensar.veterinaria.service.MascotaService;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;  
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet ("/api/mascotas")
    public class MascotaController extends HttpServlet{
    
    private final MascotaService service = new MascotaService();
    private final ObjectMapper mapper = new ObjectMapper();
     
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException{
        resp.setContentType("application/json");
        
        String id = req.getParameter("id");
        if (id != null) {
            Mascota mascota = service.buscarPorId(Long.parseLong(id));
            mapper.writeValue(resp.getWriter(), mascota);            
        }else{
            List<Mascota> mascotas = service.listarTodos();
            mapper.writeValue(resp.getWriter(), mascotas);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException{
        Mascota mascota = mapper.readValue(req.getInputStream(), Mascota.class);
        service.crear(mascota);
        resp.setStatus(HttpServletResponse.SC_CREATED);
    }
    
    @Override
    protected void doPut (HttpServletRequest req ,HttpServletResponse resp) throws IOException{
    Mascota mascota = mapper.readValue(req.getInputStream(), Mascota.class);
        service.actualizar(mascota);
        resp.setStatus(HttpServletResponse.SC_OK);
    }
    
    @Override
    protected void doDelete (HttpServletRequest req, HttpServletResponse resp) throws IOException{
        String id = req.getParameter("id");
        service.eliminar(Long.parseLong(id));
        resp.setStatus(HttpServletResponse.SC_NO_CONTENT); 
    }
    
}

