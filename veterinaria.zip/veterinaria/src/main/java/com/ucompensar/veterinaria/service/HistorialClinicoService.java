package com.ucompensar.veterinaria.service;

import com.ucompensar.veterinaria.dao.HistorialClinicoDAO;
import com.ucompensar.veterinaria.model.entity.HistorialClinico;
import com.ucompensar.veterinaria.util.JPAUtil;
import jakarta.persistence.EntityManager;
import java.util.List;

public class HistorialClinicoService {
    
    public void crear (HistorialClinico historialClinico){
        EntityManager em = JPAUtil.getEntityManager();
        try {
            new HistorialClinicoDAO(em).crear(historialClinico);
        } finally {
            em.close();
        }
    }
    
    public HistorialClinico buscarPorId(Long id){
        EntityManager em = JPAUtil.getEntityManager();
        try {
            return new HistorialClinicoDAO(em).buscarPorId(id);
        } finally {
            em.close();
        }
    }
    
    public List<HistorialClinico> listarTodos(){
        EntityManager em = JPAUtil.getEntityManager();
        try {
            return new HistorialClinicoDAO(em).listarTodos();
        } finally {
            em.close();
        }
    }
    
    public void actualizar (HistorialClinico historialClinico){
        EntityManager em = JPAUtil.getEntityManager();
        try {
                new HistorialClinicoDAO(em).actualizar(historialClinico);
        } finally {
            em.close();
        }
    }
    
    public void eliminar (Long id){
        EntityManager em = JPAUtil.getEntityManager();
        try {
            new HistorialClinicoDAO(em).eliminar(id);
        } finally {
            em.close();
        }
    }
}
