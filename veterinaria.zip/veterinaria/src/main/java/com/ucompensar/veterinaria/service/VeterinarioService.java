
package com.ucompensar.veterinaria.service;

import com.ucompensar.veterinaria.dao.VeterinarioDAO;
import com.ucompensar.veterinaria.model.entity.Veterinario;
import com.ucompensar.veterinaria.util.JPAUtil;
import jakarta.persistence.EntityManager;
import java.util.List;


public class VeterinarioService {
    
    public void crear (Veterinario veterinario){
        EntityManager em = JPAUtil.getEntityManager();
        try{
            new VeterinarioDAO(em).crear(veterinario);
        }finally{
            em.close();
        }
    }
    
    public Veterinario buscarPorId(Long id){
        EntityManager em = JPAUtil.getEntityManager();
        try{
            return new VeterinarioDAO(em).buscarPorId(id);
        }finally{
            em.close();
        }
    }
    
    public List<Veterinario> listarTodos(){
        EntityManager em = JPAUtil.getEntityManager();
        try {
            return new VeterinarioDAO(em).listarTodos();
        } finally {
            em.close();
        }
    }
    
    public void actualizar(Veterinario veterinario){
        EntityManager em = JPAUtil.getEntityManager();
        try {
            new VeterinarioDAO(em).actualizar(veterinario);
        } finally {
            em.close();
        }
    }
    
    public void eliminar(Long id){
        EntityManager em = JPAUtil.getEntityManager();
        try {
            new VeterinarioDAO(em).eliminar(id);
        } finally {
            em.close();
        }
    }
}
