package com.ucompensar.veterinaria;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;
@ApplicationPath("resources")
public class JakartaRestConfiguration extends Application {
    
}
