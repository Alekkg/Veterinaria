package com.ucompensar.veterinaria.dao;

import com.ucompensar.veterinaria.model.entity.Mascota;
import jakarta.persistence.EntityManager;
import java.util.List;


public class MascotaDAO extends GenericDAO<Mascota, Long> {
    
    public MascotaDAO(EntityManager em){
        super (em, Mascota.class);
    }
    
    public List<Mascota> buscarPorPropietario(Long idPropietario){
        return em.createQuery(
                "SELECT m FROM Mascota m WHERE m.propetario.idPropietario = :id ",
                Mascota.class
        ).setParameter("id", idPropietario)
         .getResultList();
        
    }
}

