package com.ucompensar.veterinaria.model.entity;

import jakarta.persistence.*;
import java.util.List;


@Entity
@Table(name = "medicamento")
public class Medicamento  {

   
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idmedicamento;
    
    private String nombre;
    private String tipo;
    private String presentacion;
    private String descripcion;
    
    @OneToMany(mappedBy = "medicamento")
    private List<Tratamiento> tratamientos;
    
    
//Getters - Setters
    public Long getIdmedicamento() {
        return idmedicamento;
    }

    public void setIdmedicamento(Long idmedicamento) {
        this.idmedicamento = idmedicamento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getPresentacion() {
        return presentacion;
    }

    public void setPresentacion(String presentacion) {
        this.presentacion = presentacion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public List<Tratamiento> getTratamientos() {
        return tratamientos;
    }

    public void setTratamientos(List<Tratamiento> tratamientos) {
        this.tratamientos = tratamientos;
    }   
}
