package com.ucompensar.veterinaria.dao;

import com.ucompensar.veterinaria.model.entity.Veterinario;
import jakarta.persistence.EntityManager;

public class VeterinarioDAO extends GenericDAO<Veterinario, Long>{
    
    public VeterinarioDAO(EntityManager em){
        super (em, Veterinario.class);
    }
}
